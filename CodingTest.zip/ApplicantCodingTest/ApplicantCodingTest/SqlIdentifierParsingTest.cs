﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace ApplicantCodingTest
{
	[TestFixture]
    public class SqlIdentifierParsingTest
    {
        // This test is to see how you approach a problem in a well defined space - it involves parsing out 
        // identifiers in SQL to return their constituent parts
       
        // A SQL identifier is specified as a number of parts separated by periods - an example might be:
        // database.schema.table.column

        // Each part can optionally be delimited either with [] or "" - example - [database].[schema].[table].[column]
        // or "database"."schema"."table"."column". Any text is valid within a delimited part, including periods.
		// Any part that contains non-alphanumeric characters must be delimited.

        // If a part contains a closing delimiter character, then it is escaped by doubling it. 
        // A part with a name of stupid]name would have to be specified as [stupid]]name]
        // A part with a name of stupid"name would have to be specified as "stupid""name"

        // In the case of a part delimited with [] then the opening delimiter does not need to be escaped, 
        // but still needs to be delimited - so a part with a name of some[name would need to be specified
        // as [some[name]

        // This function should return an array which contains each part, with any escaping removed.

        // There is a set of test cases below which specify the identifier to be parsed, and then the array
        // that matches the expected result

        private static string[] SplitSqlIdentifier(string identifier)
        {
            var identifierArray = identifier.Split('.');
            var tempArray = identifierArray;
            bool needToSkip = false;
            for (var i = 0; i< identifierArray.Length - 1; i ++)
            {
                if (needToSkip)
                {
                    needToSkip = false;
                    continue;
                }
                if (identifierArray[i].Contains("["))
                {
                    if (identifierArray[i+1].Contains("]"))
                    {
                        tempArray[i] = identifierArray[i].Replace("[", "") + "." + identifierArray[i+1].Replace("]", "");
                        var list = tempArray.ToList();
                        list.RemoveAt(i + 1);
                        tempArray = list.ToArray();
                        needToSkip = true;
                    }
                }
                if (identifierArray[i].IndexOf("[") == 0)
                {
                    tempArray[i] = identifierArray[i].Remove(0, 1);
                }
                if (identifierArray[i].LastIndexOf("]") + 1 == identifierArray[i].Length)
                {
                    tempArray[i] = identifierArray[i].Remove(identifierArray[i].LastIndexOf("]"), 1);
                }
                if (identifierArray[i].Contains("[["))
                {
                    tempArray[i] = identifierArray[i].Replace("[[", "[");
                }
                if (identifierArray[i].Contains("]]"))
                {
                    tempArray[i] = identifierArray[i].Replace("]]", "]");                    
                }
                if (identifierArray[i].IndexOf("\"") == 0)
                {
                    tempArray[i] = identifierArray[i].Remove(0, 1);
                }
                if (identifierArray[i].LastIndexOf("\"") + 1 == identifierArray[i].Length)
                {
                    tempArray[i] = identifierArray[i].Remove(identifierArray[i].LastIndexOf("\""), 1);
                }
                if (identifierArray[i].Contains("\"\""))
                {
                    tempArray[i] = identifierArray[i].Replace("\"\"", "\"");
                }
            }
            return tempArray;
        }

        public void AssertResult(string identifier, IEnumerable<string> expectedOutput)
        {
            var result = SplitSqlIdentifier(identifier);
            Assert.That(result, Is.Not.Null);
            Assert.That(result.SequenceEqual(expectedOutput));
        }

        [Test]
        public void CanGetSinglePartIdentifier()
        {
            AssertResult("database", new[] { "database" });
        }

        [Test]
        public void CanGetSinglePartIdentifierAndPreserveCase()
        {
            AssertResult("daTaBaSe", new[] { "daTaBaSe" });
        }

        [Test]
        public void CanGetDoublePartIdentifier()
        {
            AssertResult("database.schema", new[] { "database", "schema" });
        }

        [Test]
        public void CanGetTriplePartIdentifier()
        {
            AssertResult("database.schema.table", new[] { "database", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierWithPeriodInPart()
        {
            AssertResult("[data.base].schema.table", new[] { "data.base", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierWithEmbeddedClosingDelimiter()
        {
            AssertResult("[database]]with]]daft]]name].schema.table", new[] { "database]with]daft]name", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierWithEmbeddedClosingAndOpeningDelimiters()
        {
            AssertResult("[database]]with[daft]]name].schema.table", new[] { "database]with[daft]name", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierNameMadeOutOfDelimiters()
        {
            AssertResult("[[]]]][].schema.table", new[] { "[]][", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierWithEmbeddedQuoteDelimiter()
        {
            AssertResult("\"database\"\"with\"\"daft\"\"name\".schema.table", new[] { "database\"with\"daft\"name", "schema", "table" });
        }

        [Test]
        public void CanGetIdentifierNameMadeOutOfQuotes()
        {
            AssertResult("\"\"\"\"\"\".schema.table", new[] { "\"\"", "schema", "table" });
        }
    }
}
