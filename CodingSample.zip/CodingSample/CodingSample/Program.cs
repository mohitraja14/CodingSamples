﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingSample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose 1 for Batsman");
            Console.WriteLine("Choose 2 for Bowler");

            var input = Convert.ToInt32(Console.ReadLine());

            var cricketObject = CricketFactory.CreateObject(input);
            cricketObject.Name = "Virat";
            if (input == 1)
            {
                cricketObject.DisplayAverage(700, 10, (x, y) => x / y >= 70);
            }
            else
            {
                cricketObject.DisplayAverage(100, 10, (x, y) => x / y <= 30);
            }
            Console.WriteLine("Press any key to exit...");
            Console.Read();
        }
    }
}
