﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingSample
{
    public class CricketFactory
    {
        public static ICricket CreateObject(int choice)
        {
            ICricket cricketObject = null;

            switch (choice)
            {
                case 1:
                    cricketObject = new Batsman();
                    break;
                case 2:
                    cricketObject = new Bowler();
                    break;
                default:
                    cricketObject = new Batsman();
                    break;
            }
            return cricketObject;
        }
    }
}
