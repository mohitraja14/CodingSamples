﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingSample
{
    public interface ICricket
    {
        string Name { get; set; }
        void DisplayAverage(int arg1, int arg2, Func<int, int, bool> average);
    }
}
