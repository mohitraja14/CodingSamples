﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingSample
{
    public class Batsman : ICricket
    {
        public string Name { get; set; }

        public void DisplayAverage(int arg1, int arg2, Func<int, int, bool> average)
        {
            if (average(arg1, arg2))
            {
                Console.WriteLine(this.Name + " is a good batsman");
            }
        }
    }
}
